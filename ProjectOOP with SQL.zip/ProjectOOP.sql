-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema mydb
-- -----------------------------------------------------
-- -----------------------------------------------------
-- Schema javaproject
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema javaproject
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `javaproject` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci ;
USE `javaproject` ;

-- -----------------------------------------------------
-- Table `javaproject`.`category`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `javaproject`.`category` (
  `Category_ID` INT NOT NULL AUTO_INCREMENT,
  `category_name` VARCHAR(255) NULL DEFAULT NULL,
  PRIMARY KEY (`Category_ID`))
ENGINE = InnoDB
AUTO_INCREMENT = 11
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `javaproject`.`user`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `javaproject`.`user` (
  `User_ID` INT NOT NULL AUTO_INCREMENT,
  `username` VARCHAR(255) NULL DEFAULT NULL,
  `password` VARCHAR(255) NULL DEFAULT NULL,
  PRIMARY KEY (`User_ID`))
ENGINE = InnoDB
AUTO_INCREMENT = 9
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `javaproject`.`goal`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `javaproject`.`goal` (
  `Goal_ID` INT NOT NULL AUTO_INCREMENT,
  `title` VARCHAR(255) NULL DEFAULT NULL,
  `targetAmount` DOUBLE NULL DEFAULT NULL,
  `currentAmount` DOUBLE NULL DEFAULT NULL,
  `startDate` DATE NULL DEFAULT NULL,
  `endDate` DATE NULL DEFAULT NULL,
  `savePerDay` DOUBLE NULL DEFAULT NULL,
  `description` VARCHAR(255) NULL DEFAULT NULL,
  `User_ID` INT NULL DEFAULT NULL,
  `status` VARCHAR(255) NULL DEFAULT NULL,
  `Category_ID` INT NULL DEFAULT NULL,
  `image` LONGBLOB NULL DEFAULT NULL,
  `Remaining_Days` INT NULL DEFAULT NULL,
  PRIMARY KEY (`Goal_ID`),
  INDEX `User_ID` (`User_ID` ASC) VISIBLE,
  INDEX `FK_Category` (`Category_ID` ASC) VISIBLE,
  CONSTRAINT `FK_Category`
    FOREIGN KEY (`Category_ID`)
    REFERENCES `javaproject`.`category` (`Category_ID`),
  CONSTRAINT `goal_ibfk_1`
    FOREIGN KEY (`User_ID`)
    REFERENCES `javaproject`.`user` (`User_ID`))
ENGINE = InnoDB
AUTO_INCREMENT = 48
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `javaproject`.`goalstep`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `javaproject`.`goalstep` (
  `Step_ID` INT NOT NULL AUTO_INCREMENT,
  `amountToSave` DOUBLE NULL DEFAULT NULL,
  `Goal_ID` INT NULL DEFAULT NULL,
  PRIMARY KEY (`Step_ID`),
  INDEX `goalstep_ibfk_1` (`Goal_ID` ASC) VISIBLE,
  CONSTRAINT `goalstep_ibfk_1`
    FOREIGN KEY (`Goal_ID`)
    REFERENCES `javaproject`.`goal` (`Goal_ID`)
    ON DELETE CASCADE)
ENGINE = InnoDB
AUTO_INCREMENT = 45
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `javaproject`.`transaction`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `javaproject`.`transaction` (
  `Transaction_ID` INT NOT NULL AUTO_INCREMENT,
  `type` VARCHAR(255) NULL DEFAULT NULL,
  `amount` DOUBLE NULL DEFAULT NULL,
  `title` VARCHAR(255) NULL DEFAULT NULL,
  `description` VARCHAR(255) NULL DEFAULT NULL,
  `date` DATETIME NULL DEFAULT NULL,
  `Category_ID` INT NULL DEFAULT NULL,
  `User_ID` INT NULL DEFAULT NULL,
  PRIMARY KEY (`Transaction_ID`),
  INDEX `Category_ID` (`Category_ID` ASC) VISIBLE,
  INDEX `User_ID` (`User_ID` ASC) VISIBLE,
  CONSTRAINT `transaction_ibfk_1`
    FOREIGN KEY (`Category_ID`)
    REFERENCES `javaproject`.`category` (`Category_ID`),
  CONSTRAINT `transaction_ibfk_2`
    FOREIGN KEY (`User_ID`)
    REFERENCES `javaproject`.`user` (`User_ID`))
ENGINE = InnoDB
AUTO_INCREMENT = 44
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;

USE `javaproject`;

DELIMITER $$
USE `javaproject`$$
CREATE
DEFINER=`root`@`localhost`
TRIGGER `javaproject`.`update_remaining_days`
BEFORE INSERT ON `javaproject`.`goal`
FOR EACH ROW
BEGIN
    IF NEW.endDate IS NOT NULL THEN
        SET NEW.Remaining_Days = GREATEST(DATEDIFF(NEW.endDate, CURRENT_DATE) + 1, 0);
    END IF;
END$$

USE `javaproject`$$
CREATE
DEFINER=`root`@`localhost`
TRIGGER `javaproject`.`update_remaining_days_on_update`
BEFORE UPDATE ON `javaproject`.`goal`
FOR EACH ROW
BEGIN
    IF NEW.endDate IS NOT NULL THEN
        SET NEW.Remaining_Days = GREATEST(DATEDIFF(NEW.endDate, CURRENT_DATE) + 1, 0);
    END IF;
END$$


DELIMITER ;

SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
